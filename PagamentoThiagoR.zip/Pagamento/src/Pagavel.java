
public abstract class Pagavel {
	
	public abstract double getValorAPagar(int diaPagto, int mesPagto); 
		
}
