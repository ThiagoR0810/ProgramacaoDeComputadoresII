
public class Quadrado extends Bidimensional{

	private double lado;
	
	public Quadrado(double lado) {
		this.lado = lado;
	}
	
	public void setLado(double lado) {
		this.lado = lado;
	}
	
	public double getLado() {
		return lado;
	}
	
	public double obterArea() {
		double area = 0;
		area = (lado * lado);
		return area;
	}
}
