import java.lang.Math;

public class Triangulo extends Bidimensional {

	private double lado;
	
	public Triangulo(double lado) {
		this.lado = lado;
	}
	
	public double getLado() {
		return lado;
	}

	public void setLado(double lado) {
		this.lado = lado;
	}


	public double obterArea() {
		double area = 0;
		area = (lado * lado * Math.sqrt(3) )/4;
		return area;
	}

	


}
