
public abstract class Tridimensional implements Forma {

	public Tridimensional() {
		
	}
	
	public abstract double obterVolume();
		
	
}
