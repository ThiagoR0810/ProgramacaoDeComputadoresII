
public class Esfera extends Tridimensional {
	
	private double raio;
	
	public Esfera(double raio) {
		this.raio = raio;
	}

	public double getRaio() {
		return raio;
	}

	public void setRaio(double raio) {
		this.raio = raio;
	}
	
	public double obterArea() {
		double area = 0;
		area = (raio * raio) * Math.PI * 4;
		return area;
	}
	
	public double obterVolume() {
		double volume = 0;
		volume = ((raio * raio * raio) * Math.PI * 4)/3;
		return volume;
	}
}
