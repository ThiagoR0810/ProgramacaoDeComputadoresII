
public interface Forma {

	 double obterArea();
	
}
