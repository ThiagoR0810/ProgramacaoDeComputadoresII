
public class Cubo extends Tridimensional {
	
	private double lado;
	
	public Cubo(double lado) {
		this.lado = lado;
	}

	public double getLado() {
		return lado;
	}

	public void setLado(double lado) {
		this.lado = lado;
	}
	
	public double obterArea() {
		double area = 0;
		area = 6 * (lado * lado);
		return area;
	}
	
	public double obterVolume() {
		double volume = 0;
		volume = lado * lado * lado;
		return volume;
	}
}
