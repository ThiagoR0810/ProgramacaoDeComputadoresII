
public abstract class Bidimensional implements Forma {

	public Bidimensional() {
		
	}
	
}
