import java.lang.Math;

public class Tetraedro extends Tridimensional{
	
	private double lado;
	
	public Tetraedro(double lado) {
		this.lado = lado;
	}

	public double getLado() {
		return lado;
	}

	public void setLado(double lado) {
		this.lado = lado;
	}
	
	public double obterArea() {
		double area = 0;
		area = 4 * ((lado * lado * Math.sqrt(3) )/4);
		return area;
	}
	
	public double obterVolume() {
		double volume = 0;
		volume = (lado * lado * lado * Math.sqrt(2))/12;
		return volume;
	}

}
