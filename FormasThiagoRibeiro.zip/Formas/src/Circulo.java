import java.lang.Math;

public class Circulo extends Bidimensional{

	private double raio;
	
	public Circulo(double raio) {
		this.raio = raio;
	}
	
	public void setRaio(double raio) {
		this.raio = raio;
	}
	
	public double getRaio() {
		return raio;
	}
	
	public double obterArea() {
		double area = 0;
		area = (raio * raio) * Math.PI;
		return area;
	}
}
