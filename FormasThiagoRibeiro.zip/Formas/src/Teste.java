import java.util.ArrayList;

public class Teste {
	
	public static void main (String[] args){
		
		Circulo circulo = new Circulo(5);
		Quadrado quadrado = new Quadrado(2);
		Triangulo triangulo = new Triangulo(2);
		Esfera esfera = new Esfera(2);
		Cubo cubo = new Cubo(3);
		Tetraedro tetraedro = new Tetraedro(1);
		ArrayList<Forma> formas = new ArrayList<Forma>();
		CaixaDeBrinquedo caixa = new CaixaDeBrinquedo(formas);
		
		caixa.adiocionaFormas(circulo);
		caixa.adiocionaFormas(quadrado);
		caixa.adiocionaFormas(triangulo);
		caixa.adiocionaFormas(esfera);
		caixa.adiocionaFormas(cubo);
		caixa.adiocionaFormas(tetraedro);
		caixa.listaFormas();
		
		
	}
	
}
